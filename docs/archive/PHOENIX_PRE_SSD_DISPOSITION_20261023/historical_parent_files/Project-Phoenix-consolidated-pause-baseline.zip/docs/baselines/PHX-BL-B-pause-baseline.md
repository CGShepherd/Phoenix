# PHX-BL-B — Project Phoenix pause baseline

**Status:** Controlled pause baseline  
**Date:** 26 August 2026

## Project objective

Create a replacement balanced-input module and protected auxiliary supply for the Quad 521F amplifier.

## Baseline signal chain

`balanced input -> THAT1206 -> receiver/interface network -> original 521F amplifier input path`

## Baseline power chain

`Quad raw rails -> Architecture C -> approximately +/-17 V -> THAT1206`

## Receiver baseline

Closed:
- transformerless architecture;
- THAT1206;
- dedicated split supply;
- approximately +/-17 V;
- no electrolytics in audio signal path.

Open:
- RF/ESD network;
- grounding/shielding;
- gain/attenuation;
- original level-control strategy;
- output coupling/interface;
- final receiver PCB/connectors.

## Power/protection baseline

Closed:
- BZX55C24 + 3.6 kOhm + 47 uF;
- TIP41C/TIP42C;
- LM317/LM337;
- 120 Ohm / 1.50 kOhm;
- 100 Ohm branch resistor;
- 62 mA fuse;
- SMBJ30A;
- BZX55C30 / 2N5064 crowbar.

## Resume gate

Before full KiCad capture, close:
1. 521F input sensitivity/interface;
2. receiver gain/attenuation;
3. input RF/ESD;
4. grounding/shielding;
5. control/pot strategy;
6. DC coupling conditions.
