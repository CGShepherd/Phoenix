# PHX-ADR-002 — Balanced receiver architecture

**Status:** Accepted at architecture level; implementation details remain open.

## Decision

Use a transformerless balanced receiver based on the THAT1206 as the input-conversion stage for the Quad 521F modification.

## Closed requirements

- balanced input is required;
- transformerless implementation is preferred;
- THAT1206 is the selected receiver;
- receiver power comes from the dedicated Phoenix split supply;
- Architecture C provides approximately +/-17 V rails;
- no electrolytic capacitor is to be introduced into the audio signal path;
- preserve high common-mode rejection and avoid degrading the 521F signal path.

## Open implementation items

The following were not historically closed and must remain open:

- exact input RF/EMI and ESD network;
- connector pinout and shield/chassis termination;
- exact grounding split between chassis, signal 0 V and amplifier 0 V;
- exact THAT1206 output-to-521F interface;
- whether any DC blocking is required and, if so, the non-electrolytic implementation;
- gain/attenuation relative to original 521F input sensitivity;
- treatment of the existing logarithmic level controls;
- final receiver PCB topology, connectors and test points.

## Reopen criteria

Reopen THAT1206 only if input range, noise/distortion, mechanical implementation or bench validation demonstrates incompatibility.
