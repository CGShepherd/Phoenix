# Project Phoenix — consolidated decision register

**Purpose:** preserve receiver, power, protection and project-state decisions.

## System / receiver

| ID | Decision | Status |
|---|---|---|
| PHX-DEC-001 | Phoenix is a balanced-input module plus protected auxiliary supply for Quad 521F | CLOSED |
| PHX-DEC-002 | Use transformerless balanced input | CLOSED |
| PHX-DEC-003 | Use THAT1206 balanced receiver | CLOSED ARCHITECTURE |
| PHX-DEC-004 | Use dedicated regulated split rails for receiver | CLOSED |
| PHX-DEC-005 | Use approximately +/-17 V receiver rails | CLOSED |
| PHX-DEC-006 | No electrolytics in audio signal path | CLOSED REQUIREMENT |
| PHX-DEC-007 | Exact RF/ESD/input filtering network | OPEN |
| PHX-DEC-008 | Shield/chassis/signal-ground topology | OPEN |
| PHX-DEC-009 | Receiver gain/attenuation vs original 521F sensitivity | OPEN |
| PHX-DEC-010 | Treatment of original logarithmic level controls | OPEN |
| PHX-DEC-011 | Exact THAT1206-to-521F output coupling/interface | OPEN |
| PHX-DEC-012 | Fit within approximately 5 cm available height envelope | CONSTRAINT |

## Architecture C power/protection

| ID | Decision | Status |
|---|---|---|
| PHX-DEC-020 | Use symmetrical Architecture C | CLOSED |
| PHX-DEC-021 | LM317 / LM337 post-regulators | CLOSED |
| PHX-DEC-022 | R1 = 120 Ohm | CLOSED |
| PHX-DEC-023 | R2 = 1.50 kOhm | CLOSED |
| PHX-DEC-024 | BZX55C24 preregulator Zener | CLOSED |
| PHX-DEC-025 | 3.6 kOhm / 1 W Zener feed | CLOSED |
| PHX-DEC-026 | 47 uF Zener bypass | CLOSED |
| PHX-DEC-027 | TIP41C / TIP42C class TO-220 pass devices | CLOSED |
| PHX-DEC-028 | Retain heatsink provision | CLOSED CONSTRAINT |
| PHX-DEC-029 | 100 Ohm branch resistor | CLOSED |
| PHX-DEC-030 | 62 mA very-fast fuse, >=125 VDC | CLOSED |
| PHX-DEC-031 | SMBJ30A immediate clamp | CLOSED |
| PHX-DEC-032 | Retain SCR crowbar | CLOSED |
| PHX-DEC-033 | BZX55C30 trigger Zener | CLOSED |
| PHX-DEC-034 | 6.8 kOhm gate resistor + 47 kOhm bleed | CLOSED |
| PHX-DEC-035 | 2N5064 electrical class | CLOSED |
| PHX-DEC-036 | Do not use TI regulator macromodels as destructive-fault truth | CLOSED MODELLING RULE |

## Exact sourcing

| ID | Part | Status |
|---|---|---|
| PHX-DEC-040 | onsemi TIP41CG / TIP42CG | CLOSED SOURCING |
| PHX-DEC-041 | TI LM317AT/NOPB / LM337T/NOPB | CLOSED SOURCING |
| PHX-DEC-042 | Vishay BZX55C24-TR / BZX55C30-TR | CLOSED SOURCING |
| PHX-DEC-043 | Panasonic EEU-FR1H470 / EEU-FR1H100 | CLOSED SOURCING |
| PHX-DEC-044 | Littelfuse 0451.062MRL | CLOSED SOURCING |
| PHX-DEC-045 | Vishay AC03000001000JACCS | CLOSED SOURCING |
| PHX-DEC-046 | Littelfuse SMBJ30A | CLOSED SOURCING |
| PHX-DEC-047 | Central Semiconductor 2N5064 PBFREE | CLOSED SOURCING |

## Project state

| ID | Decision | Status |
|---|---|---|
| PHX-DEC-050 | Pause before schematic capture | ACTIVE PROJECT STATE |
| PHX-DEC-051 | Resume by closing receiver/interface open items first | RESUME RULE |
| PHX-DEC-052 | Do not re-trade Architecture C without a formal reopen criterion | CLOSED RESUME RULE |
| PHX-DEC-053 | Maintain this register as authoritative design-history index | CLOSED PROCESS RULE |

## Superseded

- PHX-BL-A asymmetric regulator concept;
- 4.7 kOhm, 3.9 kOhm and 3.3 kOhm RZ candidates;
- crowbar-only protection;
- onsemi 2N5064 sourcing.

## Change control

Before changing a CLOSED item:
1. identify the PHX-DEC ID;
2. state the reopen criterion;
3. amend/create the appropriate ADR;
4. preserve the superseded rationale;
5. update this register.
