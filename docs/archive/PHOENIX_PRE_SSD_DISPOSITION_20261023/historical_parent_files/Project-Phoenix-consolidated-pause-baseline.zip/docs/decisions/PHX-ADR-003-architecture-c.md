# PHX-ADR-003 — Architecture C branch point

**Status:** Accepted and baselined for implementation.

## Decision

Adopt the symmetrical Architecture C auxiliary-supply topology:
- filtered 24 V Zener reference;
- TIP41C/TIP42C emitter followers;
- LM317/LM337 post-regulators at approximately +/-17 V;
- per-rail fuse, pulse resistor, SMBJ30A clamp and SCR crowbar.

## Verified envelope

- raw rails: 48, 55 and 60 V design cases;
- 62 V protection stress point;
- external load: 0, 4.7, 8 and 10 mA;
- programming current: approximately 10.42 mA;
- regulated outputs: approximately +/-16.88 V.

## Accepted values

Per rail:
- BZX55C24;
- 3.6 kOhm / 1 W;
- 47 uF;
- TIP41C/TIP42C class;
- LM317/LM337;
- 120 Ohm / 1.50 kOhm set network;
- 10 uF output capacitor;
- 100 Ohm branch resistor;
- 62 mA very-fast fuse, >=125 VDC;
- SMBJ30A;
- BZX55C30;
- 2N5064-class SCR;
- 6.8 kOhm gate resistor;
- 47 kOhm gate-cathode bleed.

## Modelling boundary

TI LM317/LM337 macromodels are accepted for normal-operation verification only, not destructive-fault truth modelling.

## Reopen criteria

Reopen only if raw-rail/load envelope changes materially, selected parts prove incompatible, PCB implementation blocks the topology, or bench validation contradicts the verified margins.
