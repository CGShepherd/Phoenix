# Project Phoenix — consolidated pause / resume handover

**Date:** 26 August 2026  
**Branch:** `feature/phx-arch-c-preregulator`

## Complete

Architecture C power/protection is closed at architecture and exact-parts level.

THAT1206 receiver selection is also closed, but detailed 521F interface design remains open.

## Do not redo

Do not repeat:
- regulator architecture selection;
- Zener-feed trade;
- regulator minimum-load work;
- pass-device BF sensitivity;
- fuse/resistor trade;
- crowbar/TVS trade;
- TVS verification;
- THAT1206-vs-transformer selection.

## Receiver work still required

- confirm original 521F input sensitivity;
- close gain/attenuation;
- define input RF/ESD;
- define shield/chassis/signal-ground strategy;
- define output DC/coupling;
- close level-control strategy;
- define connector/test-point scheme.

## Resume sequence

1. read `docs/baselines/PHX-BL-B-pause-baseline.md`;
2. read `docs/decisions/PHX-DECISION-REGISTER.md`;
3. read ADR-002 and ADR-003;
4. complete receiver/interface calculations;
5. update receiver decisions;
6. create KiCad implementation branch;
7. capture receiver + Architecture C coherently;
8. bench validate.

## Historical modelling notes

- TI regulator models needed helper-subcircuit namespacing for LTspice;
- normal behavior is credible;
- destructive-fault macromodel behavior is not authoritative;
- fuse I2t must use multiplication, not caret syntax;
- final 62 V TVS-only fault current was about 235 mA;
- nominal fuse pre-arcing estimate was about 3.4 ms.
