# Project Phoenix — consolidated pause baseline pack

This supersedes the Architecture-C-only pause pack.

Contents:
- `docs/decisions/PHX-ADR-002-balanced-receiver.md`
- `docs/decisions/PHX-ADR-003-architecture-c.md`
- `docs/decisions/PHX-DECISION-REGISTER.md`
- `docs/baselines/PHX-BL-B-pause-baseline.md`
- `docs/handover/PHX-HANDOVER-2026-08-26.md`

Suggested commit:

    git add docs/decisions/PHX-ADR-002-balanced-receiver.md docs/decisions/PHX-ADR-003-architecture-c.md docs/decisions/PHX-DECISION-REGISTER.md docs/baselines/PHX-BL-B-pause-baseline.md docs/handover/PHX-HANDOVER-2026-08-26.md
    git commit -m "docs(baseline): capture complete Phoenix pause baseline"
    git push

Receiver details that were not historically closed are deliberately marked OPEN.
