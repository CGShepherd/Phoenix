# Project Phoenix — post-pause controlled follow-on

This pack records decisions made after the consolidated PHX-BL-B pause baseline. It is intentionally additive so the historical baseline remains intact.

Files:
- `docs/decisions/PHX-ADR-004-post-pause-reconciliation.md`
- `docs/decisions/PHX-DECISION-REGISTER-ADDENDUM-2026-09-12.md`

Suggested commit message:
`docs(decisions): reconcile post-pause Phoenix quantity and mechanical decisions`
