# PHX post-pause decision-register addendum

Date: 2026-09-12

| ID | Decision | Status | Reopen criterion |
|---|---|---|---|
| PHX-DEC-054 | Define one Phoenix channel as one THAT1206 receiver board plus one Architecture C PSU/protection board. | CLOSED | Electrical architecture changes such that receiver and PSU no longer form a one-channel pair. |
| PHX-DEC-055 | Define one Phoenix 521F ship set as two Phoenix channels. | CLOSED | Verified 521F channel architecture differs from the two-channel baseline. |
| PHX-DEC-056 | Immediate populated requirement for two owned 521Fs is four Phoenix channels: 4 receiver boards + 4 PSU/protection boards. | CLOSED | Fleet/build quantity changes. |
| PHX-DEC-057 | Extra bare PCBs may be procured independently of populated-build quantity. | CLOSED | Procurement strategy changes. |
| PHX-DEC-058 | Adopt the post-pause two-zone mechanical/bracket architecture; detailed geometry remains implementation-controlled. | CLOSED | Mechanical survey demonstrates infeasibility or creates an electrical/safety conflict. |

This addendum supplements, and does not rewrite, the PHX-BL-B decision register.
