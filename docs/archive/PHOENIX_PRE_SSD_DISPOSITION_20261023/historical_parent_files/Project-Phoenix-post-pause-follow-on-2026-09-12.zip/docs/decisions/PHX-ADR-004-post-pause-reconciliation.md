# PHX-ADR-004 — Post-pause quantity and mechanical architecture reconciliation

Date: 2026-09-12
Status: CLOSED / controlled follow-on to PHX-BL-B

## Purpose
Capture Phoenix decisions made after the consolidated pause baseline without rewriting or silently altering that baseline.

## Quantity / ship-set terminology
- **1 Phoenix channel** = 1 balanced receiver / THAT1206 board + 1 Architecture C PSU/protection board.
- **1 Phoenix 521F ship set** = 2 Phoenix channels = 2 receiver boards + 2 Architecture C PSU/protection boards.
- One Quad 521F is a two-channel amplifier and therefore requires one Phoenix 521F ship set.
- Current owned fleet: 2 Quad 521Fs.
- Immediate populated requirement: 2 ship sets = 4 Phoenix channels = 4 receiver boards + 4 Architecture C PSU/protection boards.
- Bare PCB procurement may exceed the immediate populated requirement to provide future-build capacity. This does not change the immediate populated BOM quantity.

## Mechanical architecture
The implementation is to use a **two-zone mechanical/bracket architecture** for the Phoenix installation. This is a packaging/interface decision, not a reopening of the accepted Architecture C electrical topology. Detailed dimensions, fixing points, connector placement, grounding implementation and final PCB outlines remain implementation-controlled until verified against the 521F mechanical envelope.

## Configuration-control effect
PHX-BL-B remains an immutable historical pause baseline. This ADR is additive. Any future change to these CLOSED decisions requires an explicit reopen criterion and decision-record update.
