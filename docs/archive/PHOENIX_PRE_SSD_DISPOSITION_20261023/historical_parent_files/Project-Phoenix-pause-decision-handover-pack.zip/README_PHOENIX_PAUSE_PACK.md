# Project Phoenix — pause decision/handover pack

Contents:
- updated `docs/decisions/PHX-ADR-003-architecture-c.md`
- new `docs/decisions/PHX-DECISION-REGISTER.md`
- new `docs/handover/PHX-HANDOVER-2026-08-25.md`

Suggested commit:

    git add docs/decisions/PHX-ADR-003-architecture-c.md docs/decisions/PHX-DECISION-REGISTER.md docs/handover/PHX-HANDOVER-2026-08-25.md
    git commit -m "docs(decisions): capture Phoenix Architecture C handover"
    git push

Maintain the decision register from this point onward; do not overwrite historical rationale.
