# Project Phoenix — decision register

**Purpose:** preserve closed design decisions and rationale so Phoenix can resume without reconstructing prior work.

**Current through:** 25 August 2026, Architecture C implementation down-selection.

| ID | Decision | Status | Rationale / evidence | Reopen only if |
|---|---|---|---|---|
| PHX-DEC-001 | Use symmetrical Architecture C instead of the earlier asymmetric LT3010/bespoke-negative approach | CLOSED | Simpler mirrored implementation passed modelling and protection verification | Hardware validation fails or source/load envelope changes materially |
| PHX-DEC-002 | Target auxiliary rails at approximately +/-17 V | CLOSED | Validated with TI regulator models and intended downstream load | Downstream requirement changes |
| PHX-DEC-003 | Use LM317 / LM337 post-regulators | CLOSED | Official TI models passed load/headroom sweeps | Vendor/rating change or hardware validation contradicts model |
| PHX-DEC-004 | Use R1 = 120 Ohm | CLOSED | Provides ~10.42 mA programming/minimum-load current and secures zero-external-load regulation | Selected regulator minimum-load requirement changes materially |
| PHX-DEC-005 | Use R2 = 1.50 kOhm | CLOSED | Produces approximately +/-16.9 V with 120 Ohm R1 | Output target changes |
| PHX-DEC-006 | Use BZX55C24 preregulator Zener | CLOSED | Stage 1/2 current and tolerance analysis matched intended operating region | Vendor part changes materially |
| PHX-DEC-007 | Use 3.6 kOhm, 1 W Zener feed resistor | CLOSED | Best thermal/current compromise; 3.9 kOhm had weaker current margin and 3.3 kOhm higher dissipation | Hardware temperature/current measurements contradict model |
| PHX-DEC-008 | Use 47 uF Zener bypass capacitor | CLOSED | Verified preregulator ripple suppression | Stability/noise measurement requires change |
| PHX-DEC-009 | Use TIP41C / TIP42C class TO-220 pass devices | CLOSED | Symmetrical pair; BF=15 bounded sensitivity passed; normal SOA benign | Thermal/availability constraint requires equivalent |
| PHX-DEC-010 | Retain provision for pass-transistor heatsinking | CLOSED IMPLEMENTATION CONSTRAINT | ~0.7-0.75 W worst normal dissipation makes enclosure temperature the main uncertainty | Hardware soak proves unnecessary |
| PHX-DEC-011 | Use 100 Ohm branch resistor | CLOSED | Negligible regulation penalty and strong fault-current limiting/crowbar coordination | Hardware fuse/crowbar test fails |
| PHX-DEC-012 | Use 62 mA very-fast branch fuse, >=125 VDC | CLOSED FUNCTION/RATING | Normal current below rating; modelled fault I2t gives millisecond-scale nominal clearing | Hardware clearing test fails |
| PHX-DEC-013 | Add SMBJ30A at each regulator input | CLOSED | Clamps destructive pass-short input to ~37.1 V, below 40 V regulator differential absolute maximum | Hardware clamp exceeds limit |
| PHX-DEC-014 | Retain SCR crowbar in addition to TVS | CLOSED | TVS handles immediate clamp; SCR forces sustained low-impedance fuse-clearing path | Alternative proven simpler/equally safe |
| PHX-DEC-015 | Use BZX55C30 crowbar trigger Zener | CLOSED | Trigger-window study gives nuisance margin above normal input and large margin below danger point | Hardware trigger window fails |
| PHX-DEC-016 | Use 6.8 kOhm gate resistor and 47 kOhm gate-cathode bleed | CLOSED | Validated sensitive-gate SCR trigger window | Different SCR gate requirement |
| PHX-DEC-017 | Use 2N5064 electrical class for crowbar SCR | CLOSED ELECTRICAL CLASS | Holding-current and available crowbar-current margins are large | Exact sourced SCR differs materially |
| PHX-DEC-018 | Source SCR as Central Semiconductor 2N5064 PBFREE | CLOSED SOURCING | Current-production source preserves verified 2N5064 class | Availability changes |
| PHX-DEC-019 | Use onsemi TIP41CG / TIP42CG | CLOSED SOURCING | Active TO-220 parts matching verified class | Availability/package changes |
| PHX-DEC-020 | Use TI LM317AT/NOPB and LM337T/NOPB | CLOSED SOURCING | Active TO-220 parts matching verified topology | Availability changes |
| PHX-DEC-021 | Use Vishay BZX55C24-TR / BZX55C30-TR | CLOSED SOURCING | Exact parts match verified Zener basis | Availability changes |
| PHX-DEC-022 | Use Panasonic FR 47 uF/50 V and 10 uF/50 V electrolytics | CLOSED SOURCING | Adequate voltage/temperature margin and low-impedance series | Stability/hardware measurement requires different ESR/capacitance |
| PHX-DEC-023 | Use Littelfuse 0451.062MRL fuse | CLOSED SOURCING | Matches 62 mA / 125 V / I2t assumptions | Hardware clearing test fails |
| PHX-DEC-024 | Use Vishay AC03-CS 100 Ohm / 3 W pulse resistor | CLOSED SOURCING | Large pulse-energy margin over simulated fault energy | Availability/size constraint |
| PHX-DEC-025 | Use Littelfuse SMBJ30A | CLOSED SOURCING | Stage 3D model explicitly based on this family | Hardware clamp test fails |
| PHX-DEC-026 | Do not use TI regulator macromodels as destructive-fault truth models | CLOSED MODELLING RULE | They produced non-physical results outside normal domain | Do not reopen; use physical fault network + datasheet limits |
| PHX-DEC-027 | Pause before schematic capture | ACTIVE PROJECT STATE | Architecture and exact parts are preserved while other project work completes | Resume Phoenix |
| PHX-DEC-028 | Resume with KiCad capture from frozen connectivity, not architecture re-trade | CLOSED RESUME RULE | Architecture and protection are already verified | Formal reopen criterion is met |

## Superseded decisions

- PHX-BL-A asymmetric regulator selection is superseded by Architecture C.
- 4.7 kOhm Zener feed resistor is superseded by 3.6 kOhm.
- 3.9 kOhm and 3.3 kOhm RZ values remain analysis history only.
- Crowbar-only protection is superseded by TVS + crowbar + fuse protection.
- onsemi 2N5064 sourcing is superseded by Central Semiconductor 2N5064 PBFREE.

## Evidence retention rule

Keep all Stage 1/2/3 LTspice decks, procedures and results as historical evidence. Do not delete old decks merely because a later deck superseded the modelling technique.

## Change-control rule

Before changing a CLOSED item:

1. identify the decision ID;
2. state which reopen criterion has been met;
3. add or amend an ADR;
4. preserve the superseded decision and rationale;
5. update this register.
