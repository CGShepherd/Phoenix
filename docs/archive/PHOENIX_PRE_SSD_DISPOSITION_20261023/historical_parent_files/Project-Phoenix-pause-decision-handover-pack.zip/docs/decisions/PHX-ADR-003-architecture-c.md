# PHX-ADR-003 — Architecture C branch point

**Status:** Accepted and baselined for implementation.

## Decision

Adopt the symmetrical Architecture C auxiliary-supply topology:

- positive rail: filtered nominal 24 V Zener reference driving a TIP41C-class emitter follower;
- negative rail: polarity-mirrored filtered nominal 24 V Zener reference driving a TIP42C-class emitter follower;
- post-regulation: LM317 / LM337 adjusted to approximately +17 V / -17 V;
- per-rail branch protection: very-fast fuse, pulse-limiting resistor, immediate TVS clamp and SCR crowbar.

## Reason for reopening the earlier trade

PHX-BL-A selected an LT3010 plus bespoke negative regulator and listed direct Zener followers and standard LM317/LM337-after-drop-stage approaches as rejected.

Architecture C was therefore an explicit branch from that earlier baseline, justified only if modelling showed that the simpler symmetrical implementation met voltage, thermal, minimum-load and fault-containment requirements with lower design risk.

That verification has now been completed through Stages 1, 2 and 3D.

## Verified operating envelope

- raw rail magnitude: 48 V, 55 V and 60 V design cases;
- additional protection stress point: 62 V;
- external load: 0, 4.7, 8 and 10 mA per rail;
- regulator programming network provides approximately 10.42 mA minimum-load current;
- nominal regulated outputs: approximately +/-16.88 V.

## Accepted electrical values

Per rail:

- preregulator Zener: BZX55C24;
- Zener feed resistor: 3.6 kOhm, 1 W;
- Zener bypass capacitor: 47 uF;
- positive/negative pass pair: TIP41C / TIP42C class;
- post-regulator: LM317 / LM337;
- set network: 120 Ohm / 1.50 kOhm;
- regulator output capacitor: 10 uF;
- branch resistor: 100 Ohm pulse-capable/flameproof;
- branch fuse: 62 mA very-fast, >=125 VDC;
- immediate clamp: SMBJ30A;
- crowbar trigger: BZX55C30;
- crowbar SCR: 2N5064 class;
- SCR gate resistor: 6.8 kOhm;
- SCR gate-cathode bleed: 47 kOhm.

## Protection rationale

The TVS is the immediate absolute-maximum clamp for the LM317/LM337 input differential.

The SCR crowbar provides the sustained low-impedance path required to force rapid fuse clearing.

The 100 Ohm branch resistor limits current and shares pulse energy.

The fuse removes sustained fault energy.

## Important modelling boundary

The official TI LM317/LM337 PSpice models are accepted for normal-operation, load, ripple and headroom verification.

They are explicitly not used as destructive-fault truth models outside their credible operating domain. Destructive pass-short protection was therefore closed using physical source/fuse/resistor/TVS/crowbar models plus datasheet absolute-maximum constraints.

## Implementation status

Architecture C is frozen at topology, electrical-value and protection-function level.

Exact manufacturer part numbers are captured in:
- `electronics/design/architecture_c_exact_parts.md`
- `electronics/bom/architecture_c_bom.csv`

Schematic connectivity is captured in:
- `electronics/design/architecture_c_schematic_connectivity.md`

## Remaining work

Remaining tasks are implementation and hardware validation, not architecture exploration:

- KiCad schematic capture;
- footprint confirmation;
- final heatsink / thermal-clip selection;
- generic resistor footprint choices;
- connector and test-point selection;
- creepage/clearance and copper-layout rules;
- bench validation to PHX-TV-008.

## Reopen criteria

Reopen Architecture C only if one of the following occurs:

- measured raw rails materially exceed the verified envelope;
- load materially exceeds the verified envelope;
- selected vendor parts reveal incompatible ratings or pinout/thermal constraints;
- physical PCB implementation prevents the required protection topology;
- bench validation contradicts the verified margins.
