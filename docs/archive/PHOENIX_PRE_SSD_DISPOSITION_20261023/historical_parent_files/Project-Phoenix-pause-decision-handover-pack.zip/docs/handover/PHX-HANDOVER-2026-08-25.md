# Project Phoenix — pause / resume handover

**Date:** 25 August 2026  
**Branch:** `feature/phx-arch-c-preregulator`

## Current state

Architecture C is closed at architecture and component-down-selection level.

Do not restart with regulator architecture selection, Zener-feed trade studies, crowbar topology exploration or fuse/resistor optimisation. Those decisions are already recorded and verified.

## Frozen architecture

Per rail:

`RAW -> 62 mA very-fast fuse -> 100 Ohm branch resistor -> BZX55C24/TIP41C-or-TIP42C preregulator -> LM317-or-LM337 -> ~17 V`

Protection at regulator input:
- SMBJ30A immediate TVS clamp;
- BZX55C30-triggered 2N5064 SCR crowbar;
- 6.8 kOhm gate resistor;
- 47 kOhm gate-cathode bleed.

Programming:
- R1 = 120 Ohm;
- R2 = 1.50 kOhm;
- output capacitor = 10 uF / 50 V;
- Zener bypass = 47 uF / 50 V.

## Exact parts

See:
- `electronics/design/architecture_c_exact_parts.md`
- `electronics/bom/architecture_c_bom.csv`

Key selected parts:
- onsemi TIP41CG / TIP42CG;
- TI LM317AT/NOPB / LM337T/NOPB;
- Vishay BZX55C24-TR / BZX55C30-TR;
- Panasonic EEU-FR1H470 / EEU-FR1H100;
- Littelfuse 0451.062MRL;
- Vishay AC03000001000JACCS;
- Littelfuse SMBJ30A;
- Central Semiconductor 2N5064 PBFREE.

## Facts worth preserving

- TI regulator models required local helper-subcircuit namespacing for LTspice coexistence.
- Their normal-operation behaviour is credible and verified.
- Their destructive-fault behaviour is not credible and must not be used for protection truth.
- 3.6 kOhm RZ is the accepted thermal/current compromise.
- 100 Ohm branch resistance has negligible normal regulation penalty.
- TVS clamp holds a faulted regulator input around 37 V in the verified model.
- SCR timing is not safety-critical because the TVS provides immediate clamp.
- Fuse I2t calculations must use `I*I`, not caret syntax.
- Final corrected TVS-only fault current at 62 V was about 235 mA.
- Nominal fuse pre-arcing estimate at that corner was about 3.4 ms.

## Open implementation items

These are not architecture decisions:
- KiCad symbol and footprint mapping;
- exact heatsink/clip;
- generic resistor footprints;
- optional local regulator input bypass capacitor;
- connector family;
- test-point style;
- creepage/clearance implementation;
- copper/heatsinking geometry;
- final board mechanical envelope.

## Resume sequence

1. read `docs/decisions/PHX-DECISION-REGISTER.md`;
2. read `docs/decisions/PHX-ADR-003-architecture-c.md`;
3. read `electronics/design/architecture_c_exact_parts.md`;
4. read `electronics/design/architecture_c_schematic_connectivity.md`;
5. read `test/procedures/PHX-TV-008-hardware-validation.md`;
6. confirm repository and branch state;
7. create an implementation branch if appropriate;
8. begin KiCad capture from the frozen connectivity;
9. validate every symbol-to-footprint pin mapping before PCB work;
10. reopen architecture only if a documented reopen criterion is met.

## First schematic checks

Before placing components:
- verify TIP41CG/TIP42CG pin order against selected footprints;
- verify LM317AT/NOPB and LM337T/NOPB pin orders independently;
- verify SMBJ30A polarity on both rails;
- verify SCR anode/cathode/gate orientation on both rails;
- treat the negative rail as a polarity mirror, not a graphical copy;
- preserve test points RAW+, RAW-, PREP, PREN, +17V, -17V and 0V.

## Hardware validation

Final implementation must be validated using:

`test/procedures/PHX-TV-008-hardware-validation.md`

Simulation closure does not replace bench validation.
